public class AchatVente extends Specialite{
    private int nbVente;

    public void acheter(){
        // pour acheter
    }

    public void Vendre(){
        // pour vendre
    }

    public void Negocier(){
        // pour negocier
    }

    public int getNbVente() {
        // pour obtenir le nombre de vente
        return nbVente;
    }

    public void setNbVente(int nbVente) {
        // pour modifier le nombre de vente
        this.nbVente = nbVente;
    }


}
