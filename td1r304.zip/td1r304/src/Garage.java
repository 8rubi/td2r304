import java.util.List;

public class Garage {
    private List<Employe> employe;
    private Garage garageattitre;

    public List<Employe> getEmploye() {
        return employe;
    }

    public void setEmploye(List<Employe> employe) {
        this.employe = employe;
    }

    public Garage getGarageattitre() {
        return garageattitre;
    }

    public void setGarageattitre(Garage garage) {
        this.garageattitre = garage;
    }
}
