public interface IAction {
    public void faire();
}
