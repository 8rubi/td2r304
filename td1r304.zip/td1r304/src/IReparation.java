public interface IReparation {
    public void reparer();
}
