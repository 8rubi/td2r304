public class Mecanique extends Specialite implements IAction, IReparation {

    public void reparer(){//pour reparer
         }

    public void faire(){//pour faire
         }
}
