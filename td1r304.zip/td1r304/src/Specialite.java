public abstract class Specialite {
    private Employe employespecialite;

    public Employe getEmployespecialite() {
        return employespecialite;
    }

    public void setEmployespecialite(Employe specialite) {
        this.employespecialite = specialite;
    }
}


