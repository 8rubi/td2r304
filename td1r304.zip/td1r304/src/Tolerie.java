public class Tolerie extends Specialite implements IReparation{

    public void Decape(){
        //pour decaper
    }

    public void reparer(){//pour repare
         }
}
